NOTE:
MD016A is the base designation for the DRV8353Rx-EVM Hardware files
MD016A(001) files are specific to the DRV8353RS-EVM
MD006B(002) files are specific to the DRV8353RH-EVM
MD017A is the ISO-F28027F Hardware files

